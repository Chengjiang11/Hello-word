package com.example.mygrocerylist.Activities;

import android.os.Bundle;

import com.example.mygrocerylist.Data.DatabaseHandler;
import com.example.mygrocerylist.Model.Reminder;
import com.example.mygrocerylist.UI.RecyclerViewAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;

import com.example.mygrocerylist.R;

import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity {
      private RecyclerView recyclerView;
      private RecyclerViewAdapter recyclerViewAdapter;
      private List<Reminder> reminderList;
      private List<Reminder> listItem;
      private DatabaseHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
            }
        });
        db=new DatabaseHandler(this);
        recyclerView=(RecyclerView)findViewById(R.id.recyclerViewID);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        reminderList =new ArrayList<>();
        listItem=new ArrayList<>();

        reminderList =db.getAllGroceries();

        for(Reminder c: reminderList){
            Reminder reminder =new Reminder();
            reminder.setName(c.getName());
            reminder.setQuantity("Qty: "+c.getQuantity());
            reminder.setId(c.getId());
            reminder.setDataItemAdded("Added on"+c.getDataItemAdded());

            listItem.add(reminder);
        }
        recyclerViewAdapter=new RecyclerViewAdapter(this,listItem);
        recyclerView.setAdapter(recyclerViewAdapter);
        recyclerViewAdapter.notifyDataSetChanged();
    }

}
