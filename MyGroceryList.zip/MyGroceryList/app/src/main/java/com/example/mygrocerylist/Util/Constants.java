package com.example.mygrocerylist.Util;

public class Constants {
     public static final int DB_VERSION=2;
     public static final String DB_NAME="ReminderList";
     public static final String TABLE_NAME="ReminderTBL";

     public static final String KEY_ID="id";
     public static final String Reminder_type ="Reminder_type";
     public static final String Reminder_name ="Reminder_name";
     public static final String KEY_DATA_NAME="date_added";

}
