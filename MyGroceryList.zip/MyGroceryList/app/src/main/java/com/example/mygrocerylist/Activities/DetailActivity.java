package com.example.mygrocerylist.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.example.mygrocerylist.R;

public class DetailActivity extends AppCompatActivity {
    private TextView itemName;
    private TextView quantity;
    private TextView dateAdded;
    private int groceryID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        itemName=(TextView)findViewById(R.id.ItemNameDet);
        quantity=(TextView)findViewById(R.id.quatityDet);
        dateAdded=(TextView)findViewById(R.id.DateAddedDet);

        Bundle bundle=getIntent().getExtras();
        if(bundle!=null){
           itemName.setText(bundle.getString("name"));
           quantity.setText(bundle.getString("quantity"));
           dateAdded.setText(bundle.getString("date"));
           groceryID=bundle.getInt("id");
        }


    }
}
