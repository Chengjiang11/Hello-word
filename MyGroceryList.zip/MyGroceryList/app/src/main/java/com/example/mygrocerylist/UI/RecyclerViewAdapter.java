package com.example.mygrocerylist.UI;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.mygrocerylist.Activities.DetailActivity;
import com.example.mygrocerylist.Data.DatabaseHandler;
import com.example.mygrocerylist.Model.Reminder;
import com.example.mygrocerylist.R;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>{
    private Context context;
    private List<Reminder> reminderItem;
    private AlertDialog.Builder alerDialogBuild;
    private AlertDialog Dialog;
    private LayoutInflater inflater;

    public RecyclerViewAdapter(Context context, List<Reminder> reminderItem) {
        this.context = context;
        this.reminderItem = reminderItem;
    }


    @NonNull
    @Override
    public RecyclerViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_row,parent,false);
        return new ViewHolder(view, context);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapter.ViewHolder holder, int position) {

                 Reminder reminder = reminderItem.get(position);
                 holder.groceryItemName.setText(reminder.getName());
                 holder.quantity.setText(reminder.getQuantity());
                 holder.dataAdded.setText(reminder.getDataItemAdded());
    }

    @Override
    public int getItemCount() {
        return reminderItem.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        public TextView groceryItemName;
        public TextView quantity;
        public TextView dataAdded;
        public Button editButton;
        public Button deleteButton;
        public int id;

        public ViewHolder(@NonNull View view,Context ctx) {
            super(view);
            context=ctx;

            groceryItemName=(TextView) view.findViewById(R.id.type);
            quantity=(TextView)view.findViewById(R.id.name1);
            dataAdded=(TextView)view.findViewById(R.id.DateAdded);
            editButton=(Button)view.findViewById(R.id.editButton);
            deleteButton=(Button)view.findViewById(R.id.deleteButton);

            editButton.setOnClickListener(this);
            deleteButton.setOnClickListener(this);

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    int position=getAdapterPosition();

                    Reminder reminder = reminderItem.get(position);
                    Intent intent=new Intent(context, DetailActivity.class);
                    intent.putExtra("name", reminder.getName());
                    intent.putExtra("quantity", reminder.getQuantity());
                    intent.putExtra("id", reminder.getId());
                    intent.putExtra("date", reminder.getDataItemAdded());
                    context.startActivity(intent);

                }
            });
        }

        @Override
        public void onClick(View v) {
             switch (v.getId()){
                 case R.id.editButton:
                     int position=getAdapterPosition();
                     Reminder reminder = reminderItem.get(position);
                     editItem(reminder);
                     break;
                 case R.id.deleteButton:
                      position=getAdapterPosition();
                     reminder = reminderItem.get(position);
                     deleteItem(reminder.getId());
                     break;

             }
        }
        public void deleteItem(final int id){
            alerDialogBuild=new AlertDialog.Builder(context);
            inflater=LayoutInflater.from(context);
            View view=inflater.inflate(R.layout.confirmation_dialog,null);
            Button nobutton=(Button)view.findViewById(R.id.noButton);
            Button yesbutton=(Button)view.findViewById(R.id.yesButton);
            alerDialogBuild.setView(view);
            Dialog=alerDialogBuild.create();
            Dialog.show();


            nobutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                  Dialog.dismiss();
                }
            });

            yesbutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    DatabaseHandler db=new DatabaseHandler(context);
                    db.deleteGrocery(id);
                    reminderItem.remove(getAdapterPosition());
                    notifyItemRemoved(getAdapterPosition());
                    Dialog.dismiss();

                }
            });

        }
        public void editItem(final Reminder reminder){
            alerDialogBuild=new AlertDialog.Builder(context);
                   inflater=LayoutInflater.from(context);
                      final View view=inflater.inflate(R.layout.pop,null);
                      final EditText groceryItem=(EditText)view.findViewById(R.id.groceryItem);
                      final EditText quantity=(EditText)view.findViewById(R.id.reminder_name);
                      final TextView title=(TextView) view.findViewById(R.id.title);
                      title.setText("Edit Reminder");
                      Button savebutton=(Button)view.findViewById(R.id.saveButton);


            alerDialogBuild.setView(view);
            Dialog=alerDialogBuild.create();
            Dialog.show();

            savebutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DatabaseHandler db=new DatabaseHandler(context);
                    reminder.setName(groceryItem.getText().toString());
                    reminder.setQuantity(quantity.getText().toString());

                    if(!groceryItem.getText().toString().isEmpty()&&!quantity.getText().toString().isEmpty()){
                     db.updateGrocery(reminder);
                     notifyItemChanged(getAdapterPosition(), reminder);

                    }else{

                        Snackbar.make(view,"Added Reminder and Quantity",Snackbar.LENGTH_LONG).show();
                    }
                    Dialog.dismiss();

                }
            });
        }
    }
}










