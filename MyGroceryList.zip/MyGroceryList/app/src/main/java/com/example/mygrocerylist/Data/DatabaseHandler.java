package com.example.mygrocerylist.Data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import com.example.mygrocerylist.Model.Reminder;
import com.example.mygrocerylist.Util.Constants;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DatabaseHandler extends SQLiteOpenHelper {
    private Context ctx;
    public DatabaseHandler(@Nullable Context context) {
        super(context, Constants.DB_NAME,null,Constants.DB_VERSION);
        this.ctx=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
    String CREATE_GROCERY_TABLE="CREATE TABLE "+Constants.TABLE_NAME+"("
            + Constants.KEY_ID+" INTEGER PRIMARY KEY,"
            + Constants.Reminder_type +" TEXT,"
            + Constants.Reminder_name +" TEXT,"
            + Constants.KEY_DATA_NAME+" LONG);";
           db.execSQL(CREATE_GROCERY_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS "+Constants.TABLE_NAME);
            onCreate(db);
    }

    //add GROCERY
    public void addGrocery(Reminder reminder){

        SQLiteDatabase db=this.getWritableDatabase();

        ContentValues values=new ContentValues();

        values.put(Constants.Reminder_type, reminder.getName());
        values.put(Constants.Reminder_name, reminder.getQuantity());
        values.put(Constants.KEY_DATA_NAME, java.lang.System.currentTimeMillis());
        //insert the row

        db.insert(Constants.TABLE_NAME,null,values);
        Log.d("Saved!","Save to DB");

    }
    public Reminder getGrocery(int id){
        SQLiteDatabase db=this.getWritableDatabase();

        Cursor cursor=db.query(Constants.TABLE_NAME,new String[]{
                Constants.KEY_ID,Constants.Reminder_type,Constants.Reminder_name,Constants.KEY_DATA_NAME},
                Constants.KEY_ID+" = ?",
                new String[]{String.valueOf(id)},null,null,null,null);

        if(cursor!=null)
            cursor.moveToFirst();

        Reminder reminder =new Reminder();
        reminder.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(Constants.KEY_ID))));
        reminder.setName(cursor.getString(cursor.getColumnIndex(Constants.Reminder_type)));
        reminder.setQuantity(cursor.getString(cursor.getColumnIndex(Constants.Reminder_name)));

        // convert timestanp
        java.text.DateFormat dateFormat=java.text.DateFormat.getDateInstance();
        String formateDate=dateFormat.format(new Date(cursor.getLong(cursor.getColumnIndex(Constants.KEY_DATA_NAME))).getTime());
        reminder.setDataItemAdded(formateDate);

        return reminder;
    }
    public List<Reminder> getAllGroceries() {
        SQLiteDatabase db = this.getReadableDatabase();
        List<Reminder> reminderList = new ArrayList<>();

        Cursor cursor = db.query(Constants.TABLE_NAME, new String[]{Constants.KEY_ID,
                        Constants.Reminder_type, Constants.Reminder_name, Constants.KEY_DATA_NAME},
                null, null, null, null, Constants.KEY_DATA_NAME + " DESC");

        if (cursor.moveToFirst()) {

            do {
                Reminder reminder = new Reminder();
                reminder.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(Constants.KEY_ID))));
                reminder.setName(cursor.getString(cursor.getColumnIndex(Constants.Reminder_type)));
                reminder.setQuantity(cursor.getString(cursor.getColumnIndex(Constants.Reminder_name)));

                // convert timestanp
                java.text.DateFormat dateFormat = java.text.DateFormat.getDateInstance();
                String formateDate = dateFormat.format(new Date(cursor.getLong(cursor.getColumnIndex(Constants.KEY_DATA_NAME))).getTime());
                reminder.setDataItemAdded(formateDate);

                reminderList.add(reminder);

            } while (cursor.moveToNext());


        }
        return reminderList;
    }
    public int updateGrocery(Reminder reminder){
        SQLiteDatabase db=this.getWritableDatabase();

        ContentValues values=new ContentValues();
        values.put(Constants.Reminder_type, reminder.getName());
        values.put(Constants.Reminder_name, reminder.getQuantity());
        values.put(Constants.KEY_DATA_NAME, java.lang.System.currentTimeMillis());
       //update rows
        return db.update(Constants.TABLE_NAME,values,Constants.KEY_ID+"=?",new String[]{String.valueOf(reminder.getId())});
    }

    public void deleteGrocery(int id){
        SQLiteDatabase db=this.getWritableDatabase();
        db.delete(Constants.TABLE_NAME,Constants.KEY_ID+" =?",new String[]{String.valueOf(id)});
        db.close();

    }
    public int getGroceriesCount(){
        String countQuery="SELECT * FROM "+Constants.TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor=db.rawQuery(countQuery,null);
        return cursor.getCount();
    }
}
