package com.example.reminder.Activities;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;

import com.example.reminder.Data.DatabaseHandler;
import com.example.reminder.Model.Reminder;
import com.example.reminder.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
   private AlertDialog.Builder dialogBuilder;
   private Dialog dialog;
   private EditText reminder_type;
   private EditText reminder_name;
   private Button savaButton;
   private DatabaseHandler db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db=new DatabaseHandler(this);
        pass();
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();

                createpopupDialog();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void createpopupDialog(){
         dialogBuilder=new AlertDialog.Builder(this);
         View view=getLayoutInflater().inflate(R.layout.popup,null);
         reminder_type=(EditText)view.findViewById(R.id.Reminder_type);
         reminder_name=(EditText)view.findViewById(R.id.reminder_name);
         savaButton=(Button)view.findViewById(R.id.saveButton);
         dialogBuilder.setView(view);
         dialog=dialogBuilder.create();
         dialog.show();


         savaButton.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 if(!reminder_type.getText().toString().isEmpty()&&
                         !reminder_name.getText().toString().isEmpty())
                 saveRemindertoDB(v);
             }
         });


    }

    private void saveRemindertoDB(View v) {
        Reminder reminder=new Reminder();
        String type=reminder_type.getText().toString();
        String name=reminder_name.getText().toString();
        reminder.setType(type);
        reminder.setName(name);


        db.addReminder(reminder);
        Snackbar.make(v,"Item Saved!",Snackbar.LENGTH_LONG).show();
        Log.d("Item Added ID:",String.valueOf(db.getReminderCount()));

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                dialog.dismiss();
                startActivity(new Intent(MainActivity.this, ListActivity.class));

            }
        },1000);

    }
       public void pass(){
   if(db.getReminderCount()>0){
    startActivity(new Intent(MainActivity.this,ListActivity.class));
    finish();

}
 }

}
