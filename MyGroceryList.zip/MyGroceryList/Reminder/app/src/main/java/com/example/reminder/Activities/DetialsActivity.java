package com.example.reminder.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import com.example.reminder.R;

public class DetialsActivity extends AppCompatActivity {
    private TextView Type;
    private TextView Name;
    private TextView date;
    private int reminderID;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detials);

        Type=(TextView) findViewById(R.id.type1);
        Name=(TextView) findViewById(R.id.name1);
        date=(TextView)findViewById(R.id.date1);

        Bundle bundle=getIntent().getExtras();
        if(bundle!=null){
            Type.setText(bundle.getString("type"));
            Name.setText(bundle.getString("name"));
            date.setText(bundle.getString("date"));
            reminderID=bundle.getInt("id");

        }
    }
}
