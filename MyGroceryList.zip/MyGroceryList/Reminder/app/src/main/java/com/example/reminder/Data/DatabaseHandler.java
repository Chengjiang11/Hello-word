package com.example.reminder.Data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import com.example.reminder.Model.Reminder;
import com.example.reminder.Util.Constants;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DatabaseHandler extends SQLiteOpenHelper {
    private Context ctx;
    public DatabaseHandler(@Nullable Context context) {
        super(context, Constants.DB_NAME, null, Constants.DB_version);
        this.ctx=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
            String  Create_Reminder_Table="CREATE TABLE "+Constants.TABLE_NAME+"("
                    +Constants.Key_ID+" INTEGER PRIMARY KEY,"
                    +Constants.Key_type+" TEXT,"
                    +Constants.KEY_name+" TEXT,"
                    +Constants.Key_date+" LONG);";
            db.execSQL(Create_Reminder_Table);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+Constants.TABLE_NAME);
        onCreate(db);

    }
    public void addReminder(Reminder reminder){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(Constants.Key_type,reminder.getType());
        values.put(Constants.KEY_name,reminder.getName());
        values.put(Constants.Key_date,java.lang.System.currentTimeMillis());
        db.insert(Constants.TABLE_NAME,null,values);
        Log.d("Save!","Saved to DB");

    }

    public Reminder getReminder(int id){
        SQLiteDatabase db=this.getWritableDatabase();

        Cursor cursor=db.query(Constants.TABLE_NAME,new String[]{Constants.Key_ID,Constants.Key_type,Constants.KEY_name,Constants.Key_date},
                Constants.Key_ID+"=?",new String[]{String.valueOf(id)},null,null,null,null);

        if(cursor!=null)
            cursor.moveToFirst();
        Reminder reminder=new Reminder();
        reminder.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(Constants.Key_ID))));
        reminder.setType(cursor.getString(cursor.getColumnIndex(Constants.Key_type)));
        reminder.setName(cursor.getString(cursor.getColumnIndex(Constants.KEY_name)));

        java.text.DateFormat dateFormat=java.text.DateFormat.getDateInstance();
        String formatedDate=dateFormat.format(new Date(cursor.getLong(cursor.getColumnIndex(Constants.Key_date))).getTime());
        reminder.setDate(formatedDate);
        return reminder;
    }
    public List<Reminder> getAllReminders(){
        SQLiteDatabase db=this.getReadableDatabase();
        List<Reminder> reminderList=new ArrayList<>();

        Cursor cursor=db.query(Constants.TABLE_NAME,new String[]{Constants.Key_ID,Constants.Key_type,Constants.KEY_name,Constants.Key_date},
                null,null,null,null,Constants.Key_date+" DESC");
        if(cursor.moveToFirst()){
               do{
                   Reminder reminder=new Reminder();
                   reminder.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(Constants.Key_ID))));
                   reminder.setType(cursor.getString(cursor.getColumnIndex(Constants.Key_type)));
                   reminder.setName(cursor.getString(cursor.getColumnIndex(Constants.KEY_name)));
                   java.text.DateFormat dateFormat=java.text.DateFormat.getDateInstance();
                   String formatedDate=dateFormat.format(new Date(cursor.getLong(cursor.getColumnIndex(Constants.Key_date))).getTime());
                   reminder.setDate(formatedDate);
                   reminderList.add(reminder);

               }while (cursor.moveToNext());
        }
        return reminderList;
    }
    public int updatedReminder(Reminder reminder){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(Constants.Key_type,reminder.getType());
        values.put(Constants.KEY_name,reminder.getName());
        values.put(Constants.Key_date,java.lang.System.currentTimeMillis());

        return db.update(Constants.TABLE_NAME,values,Constants.Key_ID+"=?",new String[]{String.valueOf(reminder.getId())});
    }
    public void deleteReminder(int id){
        SQLiteDatabase db=this.getWritableDatabase();
        db.delete(Constants.TABLE_NAME,Constants.Key_ID+" = ?",new String[]{String.valueOf(id)});
        db.close();
    }
    public int getReminderCount(){
        String countQuery="SELECT * FROM "+Constants.TABLE_NAME;
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery(countQuery,null);

        return cursor.getCount();
    }
}
