package com.example.reminder.Activities;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;

import com.example.reminder.Data.DatabaseHandler;
import com.example.reminder.Model.Reminder;
import com.example.reminder.UI.RecyclerViewAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.reminder.R;

import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity {
     private RecyclerView recyclerView;
     private RecyclerViewAdapter recyclerViewAdapter;
     private List<Reminder> reminderList;
     private List<Reminder> listItem;
     private DatabaseHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();

                createpopupDialog();

            }
        });

        db=new DatabaseHandler(this);
        recyclerView=(RecyclerView) findViewById(R.id.recyclerViewID);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        reminderList=new ArrayList<>();
        listItem=new ArrayList<>();

        reminderList=db.getAllReminders();

          for (Reminder c:reminderList){
              Reminder reminder=new Reminder();
              reminder.setType(c.getType());
              reminder.setName("name:"+c.getName());
              reminder.setId(c.getId());
              reminder.setDate("Added on: "+c.getDate());

          listItem.add(reminder);
          }

          recyclerViewAdapter=new RecyclerViewAdapter(this,listItem);
          recyclerView.setAdapter(recyclerViewAdapter);
          recyclerViewAdapter.notifyDataSetChanged();
    }

    private void createpopupDialog() {
    }


}

