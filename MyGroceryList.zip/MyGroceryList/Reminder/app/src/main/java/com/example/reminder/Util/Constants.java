package com.example.reminder.Util;

public class Constants {
   public static final int DB_version=2;
   public static final String DB_NAME="ReminderDB";
   public static final String TABLE_NAME="ReminderTAB";


   public static final String Key_ID="id";
   public static final String Key_type="Reminder_type";
   public static final String KEY_name="Reminder_name";
   public static final String Key_date="date_added";


}
