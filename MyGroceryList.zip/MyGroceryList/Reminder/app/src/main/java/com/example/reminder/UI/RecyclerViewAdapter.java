package com.example.reminder.UI;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.reminder.Activities.DetialsActivity;
import com.example.reminder.Data.DatabaseHandler;
import com.example.reminder.Model.Reminder;
import com.example.reminder.R;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
    private Context context;
    private List<Reminder> ReminderItems;
    private AlertDialog.Builder alertDialogBuilder;
    private AlertDialog dialog;
    private LayoutInflater inflater;

    public RecyclerViewAdapter(Context context, List<Reminder> ReminderItems) {
        this.context = context;
        this.ReminderItems = ReminderItems;
    }

    @Override
    public RecyclerViewAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_row, parent, false);

        return new ViewHolder(view, context);
    }

    @Override
    public void onBindViewHolder(RecyclerViewAdapter.ViewHolder holder, int position) {

        Reminder reminder =ReminderItems.get(position);
        holder.ReminderItemType.setText(reminder.getType());
        holder.name.setText(reminder.getName());
        holder.dateAdded.setText(reminder.getDate());

    }

    @Override
    public int getItemCount() {

        return ReminderItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView ReminderItemType;
        public TextView name;
        public TextView dateAdded;
        public Button editButton;
        public Button deleteButton;
        public int id;


        public ViewHolder(View view, Context ctx) {
            super(view);

            context = ctx;

            ReminderItemType = (TextView) view.findViewById(R.id.type);
            name = (TextView) view.findViewById(R.id.name1);
            dateAdded = (TextView) view.findViewById(R.id.dateAdded);

            editButton = (Button) view.findViewById(R.id.editButton);
            deleteButton = (Button) view.findViewById(R.id.deleteButton);

            editButton.setOnClickListener(this);
            deleteButton.setOnClickListener(this);


            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // go to next screen
                    int position=getAdapterPosition();
                    Reminder reminder=ReminderItems.get(position);
                    Intent intent=new Intent(context, DetialsActivity.class);
                    intent.putExtra("type",reminder.getType());
                    intent.putExtra("name",reminder.getName());
                    intent.putExtra("id",reminder.getId());
                    intent.putExtra("date",reminder.getDate());
                    context.startActivity(intent);

                }
            });

        }


        @Override
        public void onClick(View v) {
               switch (v.getId()){
                   case R.id.editButton:
                       int position=getAdapterPosition();
                       Reminder reminder=ReminderItems.get(position);
                       EditedButton(reminder);
                       break;

                   case R.id.deleteButton:
                       position=getAdapterPosition();
                       reminder=ReminderItems.get(position);
                      DeleteButton(reminder.getId());
                      break;
               }
        }
        public void DeleteButton(final int id){

            alertDialogBuilder=new AlertDialog.Builder(context);

            inflater=LayoutInflater.from(context);
            View view=inflater.inflate(R.layout.check,null);

            Button noButton=(Button) view.findViewById(R.id.noButton);
            Button yesButton=(Button) view.findViewById(R.id.yesButton);

            alertDialogBuilder.setView(view);
            dialog=alertDialogBuilder.create();
            dialog.show();

            noButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                     dialog.dismiss();
                }
            });

            yesButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DatabaseHandler db=new DatabaseHandler(context);

                    db.deleteReminder(id);
                    ReminderItems.remove(getAdapterPosition());
                    notifyItemRemoved(getAdapterPosition());

                    dialog.dismiss();


                }
            });

        }

        public void EditedButton(final Reminder reminder){
            alertDialogBuilder=new AlertDialog.Builder(context);
            inflater=LayoutInflater.from(context);

            final View view=inflater.inflate(R.layout.popup,null);
            final EditText type=(EditText)view.findViewById(R.id.Reminder_type);
            final EditText name=(EditText)view.findViewById(R.id.reminder_name);
            final TextView title=(TextView)view.findViewById(R.id.title);
            title.setText("Edit Reminder");
            Button button=(Button)view.findViewById(R.id.saveButton);
            alertDialogBuilder.setView(view);
            dialog=alertDialogBuilder.create();
            dialog.show();
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DatabaseHandler db=new DatabaseHandler(context);

                    reminder.setType(type.getText().toString());
                    reminder.setName(name.getText().toString());
                    if(!type.getText().toString().isEmpty()&&!name.getText().toString().isEmpty()){

                        db.updatedReminder(reminder);
                        notifyItemChanged(getAdapterPosition(),reminder);
                    }

                    else
                    {
                        Snackbar.make(v,"Added it",Snackbar.LENGTH_LONG);
                    }
                    dialog.dismiss();
                }
            });

        }
    }

}

